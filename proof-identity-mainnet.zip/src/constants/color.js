export const PRIMARY_COLOR = '#fe7a3c';
export const DISABLE_COLOR = '#c4c4c4';
export const GREEN_COLOR = '#37A504';
export const RED_COLOR = '#eb1515';
export const RADICAL_RED = '#ff385c';
export const BLUE_COLOR = '#009df5';
export const WHITE_COLOR = '#ffffff';
export const SLIDER_RAIL_COLOR = "#e9e9e9";