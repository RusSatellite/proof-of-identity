import './modal.css';
import { useDispatch, useSelector } from "react-redux";
import { CloseButton } from 'react-bootstrap';
import * as Actions from "../../store/actions"
import { PayPalButton } from "react-paypal-button-v2";

const PaymentModal = () => {
    const dispatch = useDispatch();
    const state = useSelector(({fuse}) => fuse.payment_modal.state);
    const value = useSelector(({fuse}) => fuse.payment_modal.value);
    const showHideClassName = state ? "payment-modal display-block" : "payment-modal display-none";

    const handleClose = (e) => {
        e.preventDefault();
        dispatch(Actions.hide_payment_modal());
    }

    const handlePaypal = (e) => {
        e.preventDefault();
        dispatch(Actions.hide_payment_modal());
    }

    const handleCoinbase = async(e) => {
        e.preventDefault();
        dispatch(Actions.hide_payment_modal());
        // const result = await coinbaseService({
        //     amount: value,
        //     real_amount: value,
        //     discount_1: 0,
        //     discount_2: 0,
        // });
        // if ("errors" in result) {
        //     console.log(result.errors);
        // } else {
        //     window.location.href =  result.data.hosted_url;
        // }
    }

    return (
        <div className={showHideClassName}>
            <div className="app-content-height d-flex flex-column align-items-center justify-content-center payment-modal-main">
                <div className="fw-600 fs-2p0 cod-gray">You will pay {value} € with<CloseButton onClick={handleClose}/></div>
                <div>
                    <button className='btn btn-app-dark-gray py-2 position-relative'  style={{minHeight: "3rem", minWidth: "6rem", margin: "10px"}} onClick={handlePaypal}>Paypal</button>
                    <button className='btn btn-app-dark-gray py-2 position-relative'  style={{minHeight: "3rem", minWidth: "6rem", margin: "10px"}} onClick={handleCoinbase}>Coinbase</button>
                </div>
                {/* <PayPalButton
                    createOrder={(data, actions) => {
                    return actions.order.create({
                        purchase_units: [{
                        amount: {
                            currency_code: "USD",
                            value: "0.01"
                        }
                        }],
                        // application_context: {
                        //   shipping_preference: "NO_SHIPPING" // default is "GET_FROM_FILE"
                        // }
                    });
                    }}
                    onApprove={(data, actions) => {
                    // Capture the funds from the transaction
                    return actions.order.capture().then(function(details) {
                        // Show a success message to your buyer
                        alert("Transaction completed by " + details.payer.name.given_name);

                        // OPTIONAL: Call your server to save the transaction
                        return fetch("/paypal-transaction-complete", {
                        method: "post",
                        body: JSON.stringify({
                            orderID: data.orderID
                        })
                        });
                    });
                    }}
                /> */}
            </div>
        </div>
    );
};

export default PaymentModal;