import Payment from '../payment';

const Payment2 = () => {

    return (
        <Payment amount={500}/>
    );
};

export default Payment2;