import Payment from '../payment';

const Payment1 = () => {

    return (
        <Payment amount={20}/>
    );
};

export default Payment1;